/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication4;

/**
 *
 * @author muhammaddyasyaskur
 */
class V6Engine implements Engine {

    public V6Engine() {
    }

    @Override
    public int getMaxSpeed() {
 int maxspeed = 300;
return maxspeed;    }
    
}
