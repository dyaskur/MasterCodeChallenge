/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication4;

/**
 *
 * @author muhammaddyasyaskur
 */
class ItalicElement extends MarkupElement {

    public ItalicElement(String open, String close) {
        this.settag(open, close);
    }
    
}
